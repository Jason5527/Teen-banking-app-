
import React, { useState } from 'react';

function App() {
  const [balance, setBalance] = useState(0);
  const [points, setPoints] = useState(0);
  const [cardOrdered, setCardOrdered] = useState(false);

  const earnPoints = () => setPoints(points + 10);
  const convertPointsToCash = () => {
    if (points >= 10) {
      setBalance(balance + 1);
      setPoints(points - 10);
    }
  };

  const orderCard = () => setCardOrdered(true);

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: 'auto', fontFamily: 'Arial' }}>
      <h1>Teen Banking App</h1>
      <p><strong>Balance:</strong> ${balance.toFixed(2)}</p>
      <p><strong>Points:</strong> {points}</p>

      <button onClick={earnPoints} style={{ marginTop: '10px', width: '100%' }}>
        Play Game (Earn 10 pts)
      </button>

      <button
        onClick={convertPointsToCash}
        style={{ marginTop: '10px', width: '100%' }}
        disabled={points < 10}
      >
        Convert 10 pts → $1
      </button>

      <div style={{ marginTop: '20px' }}>
        <h3>My Card</h3>
        {cardOrdered ? (
          <p>Your free debit card is on the way! 🎉</p>
        ) : (
          <button onClick={orderCard} style={{ width: '100%' }}>
            Order My Free Card
          </button>
        )}
      </div>
    </div>
  );
}

export default App;
